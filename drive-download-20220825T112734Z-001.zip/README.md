# substring in Python

## Overview:

The python string[start: end: step] method returns a part of the string.
We pass start index and end index number position where both start and end index is exclusive.

## Task

### "Without own words"
Please write a program that prints out "Hello Gregor". The challenge is that you are not allowed to create own chars & strings. You are only allowed to use elements of a given string provided in the solution.py file.


### Output
```
"Hello Gregor"
```
